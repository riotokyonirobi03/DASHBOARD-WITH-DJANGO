from django import forms
from .models import Data
import csv
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class csvimport(forms.Form):
	csv_file=forms.FileField()
	

class DataForm(forms.ModelForm):
    class Meta:
        model = Data
        fields = '__all__'


class CustomUserCreationForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'password1', 'password2']

    def clean_username(self):
        username = self.cleaned_data['username']
        if User.objects.filter(username=username).exists():
            raise forms.ValidationError('This username is already taken.')
        return username
