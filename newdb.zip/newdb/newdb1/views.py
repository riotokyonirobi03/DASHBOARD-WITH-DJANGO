# myapp/views.py
from django.http import HttpResponse
from django.db import connection
import sqlite3
from django.http import JsonResponse
from .forms import DataForm
from datetime import datetime
from django.shortcuts import render,reverse
from django.views import View
from .forms import CustomUserCreationForm
from django.contrib.auth.views import LoginView
from django.urls import path
from django.shortcuts import redirect
from django.contrib.auth.views import LogoutView as BaseLogoutView
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
import csv
from .forms import csvimport
from .models import TELANGANA
from django.db import transaction
from django.db.models import Count


def read_csv(request):
    if request.method == 'POST':
        form = csvimport(request.POST, request.FILES)
        if form.is_valid():
            csv_file = request.FILES['csv_file']
            decoded_file = csv_file.read().decode('utf-8').splitlines()
            csv_reader = csv.reader(decoded_file)
            header = next(csv_reader)
            state_value = request.POST.get('state_name')
            
            telangana_fields = [field.name for field in TELANGANA._meta.get_fields() if field.name != 'id']
            
            if state_value == "TELANGANA":
                with transaction.atomic():
                    for _, row in enumerate(csv_reader):
                        telangana_data = {}
                        for idx, field_value in enumerate(row):
                            if idx < len(telangana_fields):
                                telangana_data[telangana_fields[idx]] = field_value
                        
                        # Save each row to the database
                        TELANGANA.objects.create(**telangana_data)
                    
                    # Prepare response data
                    response_data = {
                        "success": True,
                        "total_rows": _ + 1  # Total rows processed
                    }
                    return JsonResponse(response_data)
    else:
        form = csvimport()
        
    return render(request, 'upload.html', {'form': form})

def donut_chart_data(request):
    # Fetch data from the TELANGANA model
    data = TELANGANA.objects.all()

    # Extract relevant data for the donut chart
    categories = data.values_list('category_n', flat=True)
    subcategories = data.values_list('subcateg_1', flat=True)
    completions = data.values_list('completion', flat=True)

    # Sample aggregation logic to count occurrences of each category/subcategory
    category_counts = dict(Counter(categories))
    subcategory_counts = dict(Counter(subcategories))
    # You can add similar aggregation logic for completion dates if needed

    # Prepare data for the chart
    category_labels = list(category_counts.keys())
    category_values = list(category_counts.values())
    subcategory_labels = list(subcategory_counts.keys())
    subcategory_values = list(subcategory_counts.values())

    data = {
        'category_labels': category_labels,
        'category_values': category_values,
        'subcategory_labels': subcategory_labels,
        'subcategory_values': subcategory_values,
    }

    return JsonResponse(data)

def get_financial_years():
    current_year = datetime.now().year
    financial_years = [f"{year}-{str(year + 1)[2:]}" for year in range(current_year, current_year - 20, -1)]
    # Remove the current financial year
    financial_years.remove(f"{current_year}-{str(current_year + 1)[2:]}")
    # Add "All" option
    financial_years.insert(0,"Select Financial Year" "All")
    return financial_years

def get_category_options():
    # Replace this with your actual logic to fetch categories from the database
    categories = ["select Category", "Accepted", "Pending", "Rejected", "Collection Report", "Assets Geotagging state",
                  "Geotag Spending for Module"]
    return categories

def get_subcategory_options():
    # Replace this with your actual logic to fetch subcategories from the database
    subcategories = ["Select Subcategory", "Costal Areas", "Other Works", "Works on Individuals Land (Category IV)",
                     "Drought Proofing", "Micro Irrigation Works", "Play Ground", "Anganwadi/Other Rural Infrastructure",
                     "Rural Sanitation", "Food Grain", "Land Development", "Renovation of Traditional water Bodies",
                     "Rural Drinking Water", "water Conservation and Water Harvesting", "Flood Control and Protection",
                     "Fisheries", "Rural Connectivity", "Bharat Nirman Sewa Kendra"]
    return subcategories

def index(request):
    form = DataForm()
    if request.method == 'POST':
        form = DataForm(request.POST)
        if form.is_valid():
            form.save()
            financial_years = get_financial_years()  # Update financial years after form submission
            return JsonResponse({'success': True, 'financial_years': financial_years, 'category_options': get_category_options(),
                                 'subcategory_options': get_subcategory_options()})

    financial_years = get_financial_years()
    category_options = get_category_options()
    subcategory_options = get_subcategory_options()

    return render(request, 'index.html',
                  {'form': form, 'financial_years': financial_years, 'category_options': category_options,
                   'subcategory_options': subcategory_options})



urlpatterns = [
    path('login/', LoginView.as_view(template_name='login.html'), name='login'),
]

class UserCreationView(View):
    template_name='createuser.html'

    def get(self,request):
        form= CustomUserCreationForm()
        return render(request,self.template_name,{'form':form})

    def post(self,request):
        form=CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
        else:
            print("form not valid")
        return render(request,self.template_name,{'form':form})

class LogoutView(BaseLogoutView):
    def get_next_page(self):
        next_page = super().get_next_page()
        return reverse('login')

