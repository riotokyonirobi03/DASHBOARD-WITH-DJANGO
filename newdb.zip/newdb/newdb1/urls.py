from django.urls import include,path
from .views import index
from django.contrib.auth.views import LoginView,LogoutView
from .views import UserCreationView
from . import views

urlpatterns = [
    path('db/', index, name='index'),
    #path('results/', results, name='results'),
    path('login/', LoginView.as_view(template_name='login.html'), name='login'),
    path('createuser/',UserCreationView.as_view(template_name='createuser.html'), name='createuser'),
    path('db/import/',views.read_csv,name='read_csv'),
    path('logout', LogoutView.as_view(), name='logout'),
    path('donut_chart_data/', views.donut_chart_data, name='donut_chart_data')
]
