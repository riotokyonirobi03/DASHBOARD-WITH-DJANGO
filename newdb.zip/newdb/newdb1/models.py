from django.db import models
from django.contrib.auth.models import AbstractUser

class Data(models.Model):
    financial_year = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    district = models.CharField(max_length=100)
    block = models.CharField(max_length=100)
    panchayat = models.CharField(max_length=100)
    category = models.CharField(max_length=100)
    sub_category = models.CharField(max_length=100)
    value = models.FloatField()

#class Result(models.Model):
    #financial_year = models.CharField(max_length=10)
    #state = models.CharField(max_length=100)
    #district = models.CharField(max_length=100)
    #result1 = models.IntegerField()
    #result2 = models.IntegerField()
    #result3 = models.IntegerField()

    #def __str__(self):
        #return f"{self.financial_year} - {self.state} - {self.district}"


class TELANGANA(models.Model):
    collection=models.CharField(max_length=100,null=False)
    asset_id=models.CharField(max_length=100,null=False)
    lon=models.CharField(max_length=100,null=False)
    lat=models.CharField(max_length=100,null=False)
    asset_name=models.CharField(max_length=100,null=False)
    work_code=models.CharField(max_length=100,null=False)
    work_name=models.CharField(max_length=100,null=False)
    category_n=models.CharField(max_length=100,null=False)
    subcateg_1=models.CharField(max_length=100,null=False)
    state_name=models.CharField(max_length=100,null=False)
    district_n=models.CharField(max_length=100,null=False)
    block_name=models.CharField(max_length=100,null=False)
    panchaya_1=models.CharField(max_length=100,null=False)
    work_finan=models.DateField()
    completion=models.DateField()
    asset_tag=models.DateField()
    work_start=models.DateField()
    mat_expend=models.CharField(max_length=100,null=False)
    sk_ssk_exp=models.CharField(max_length=100,null=False)
    persondays=models.CharField(max_length=100,null=False)
    us_expendi=models.CharField(max_length=100,null=False)
    work_compl=models.DateField()
    class Meta:
        managed=True
        db_table='Telangana'
        unique_together=('collection','asset_id','work_code')
    def __str__(self):
        return str(self.asset_id), self.collection, self.work_code
